

<p><b>Title</b> => <i>{{ $title }}</i>, <b>ID</b> => <i>{{ $id }}</i>, <b>Cat</b> => <i>{{ $cat }}</i></p>