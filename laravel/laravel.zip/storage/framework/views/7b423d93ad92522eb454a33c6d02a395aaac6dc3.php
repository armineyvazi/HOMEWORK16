

<p><b>Title</b> => <i><?php echo e($title); ?></i>, <b>ID</b> => <i><?php echo e($id); ?></i>, <b>Cat</b> => <i><?php echo e($cat); ?></i></p><?php /**PATH C:\xampp\htdocs\maktab\Homework\16\laravel\resources\views/sport/index.blade.php ENDPATH**/ ?>